// SPDX-License-Identifier: GPL-3.0-or-later
import SwiftUI
import Foundation
import Library
import Libbox
import NetworkExtension
import UniformTypeIdentifiers
import UIKit

private struct ShareFile: Identifiable { let id = UUID(); let url: URL }
private struct ShareSheet: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: [url], applicationActivities: nil)
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}

// HTTPS only, including redirects. No credentials, cookies or analytics.
private final class HTTPSOnly: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(request.url?.scheme?.lowercased() == "https" ? request : nil)
    }
}

@MainActor
private final class OnlineController: ObservableObject {
    @Published var tunnel: ExtensionProfile?
    @Published var busy = false
    @Published var errorMessage: String?
    @Published var imported = false
    private var initialized = false
    private var ready = false
    private let name = "VNBAPEX BYPASS"
    private var delegate = HTTPSOnly()
    private var statusObserver: NSObjectProtocol?
    var status: NEVPNStatus { tunnel?.status ?? .disconnected }
    var connected: Bool { status == .connected || status == .reasserting }
    var transitioning: Bool { status == .connecting || status == .disconnecting || status == .reasserting }
    var remoteURL: URL? {
        guard let raw = Bundle.main.object(forInfoDictionaryKey: "RemoteConfigURL") as? String,
              let url = URL(string: raw), url.scheme?.lowercased() == "https", url.host != nil else { return nil }
        return url
    }
    private func failure(_ message: String) -> NSError {
        NSError(domain: "VNBAPEX", code: 1, userInfo: [NSLocalizedDescriptionKey: message])
    }
    func initialize() async {
        guard !initialized else { return }
        initialized = true
        do {
            guard let group = Bundle.main.object(forInfoDictionaryKey: "AppGroupIdentifier") as? String,
                  FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group) != nil else {
                throw failure("App chưa được ký với quyền App Groups phù hợp. Cần ký cả app và extension với Network Extension.")
            }
            try ServiceSetup.apply(crashReportSource: "VNBAPEX")
            ready = true
            try ApplicationLocale.apply()
            try await loadTunnel()
            statusObserver = NotificationCenter.default.addObserver(forName: .NEVPNStatusDidChange, object: nil, queue: .main) { [weak self] _ in
                Task { @MainActor [weak self] in self?.objectWillChange.send() }
            }
        } catch { errorMessage = error.localizedDescription }
        await refresh(showError: false)
    }
    private func loadTunnel() async throws {
        tunnel = try await ExtensionProfile.load()
        tunnel?.register()
    }
    // Decode and validate away from the UI thread. BPF is a sing-box profile container,
    // not a JSON file: use the official decoder, never rename the extension.
    private func validated(_ data: Data, bpf: Bool) async throws -> String {
        guard data.count <= 2_097_152 else { throw failure("Tệp vượt quá 2 MB.") }
        return try await Task.detached(priority: .userInitiated) {
            let text: String
            if bpf { text = try LibboxProfileContent.from(data).config }
            else {
                guard let value = String(data: data, encoding: .utf8) else {
                    throw NSError(domain: "VNBAPEX", code: 2, userInfo: [NSLocalizedDescriptionKey: "JSON phải dùng UTF-8."])
                }
                text = value
            }
            _ = try JSONSerialization.jsonObject(with: Data(text.utf8), options: [.fragmentsAllowed])
            var error: NSError?
            LibboxCheckConfig(text, &error)
            if let error { throw error }
            return text
        }.value
    }
    private func save(_ text: String) async throws {
        if let profile = try await ProfileManager.get(by: name) {
            let old = try await profile.readAsync()
            if old != text {
                try await profile.writeAsync(text)
                do {
                    if connected { try await tunnel?.reloadService() }
                } catch {
                    try await profile.writeAsync(old)
                    try? await tunnel?.reloadService()
                    throw error
                }
            }
            profile.lastUpdated = Date()
            try await ProfileManager.update(profile)
            await SharedPreferences.selectedProfileID.set(profile.mustID)
        } else {
            let content = LibboxProfileContent()
            content.name = name
            content.type = 0 // Controlled local snapshot; remote URL lives in the app.
            content.config = text
            content.autoUpdate = false
            _ = try await content.importProfile()
        }
    }
    func refresh(showError: Bool = true) async {
        guard ready, !busy, !transitioning else { return }
        if !showError && UserDefaults.standard.bool(forKey: "localPreviewPending") { return }
        busy = true
        defer { busy = false }
        do {
            guard let url = remoteURL else { throw failure("Chưa thiết lập địa chỉ HTTPS trong workflow.") }
            let configuration = URLSessionConfiguration.ephemeral
            configuration.timeoutIntervalForRequest = 20
            configuration.timeoutIntervalForResource = 40
            configuration.httpCookieStorage = nil
            let session = URLSession(configuration: configuration, delegate: delegate, delegateQueue: nil)
            defer { session.invalidateAndCancel() }
            var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData)
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            let (bytes, response) = try await session.bytes(for: request)
            guard let http = response as? HTTPURLResponse, http.statusCode == 200,
                  http.url?.scheme?.lowercased() == "https" else { throw failure("Không tải được config.json qua HTTPS.") }
            if response.expectedContentLength > 2_097_152 { throw failure("Tệp vượt quá 2 MB.") }
            var data = Data()
            for try await byte in bytes {
                guard data.count < 2_097_152 else { throw failure("Tệp vượt quá 2 MB.") }
                data.append(byte)
            }
            let text = try await validated(data, bpf: false)
            try await save(text)
            UserDefaults.standard.set(false, forKey: "localPreviewPending")
        } catch {
            if showError { errorMessage = error.localizedDescription }
        }
    }
    func toggle() async {
        guard ready, !busy, !transitioning else { return }
        busy = true
        defer { busy = false }
        do {
            if connected { try await tunnel?.stop(); return }
            guard let profile = try await ProfileManager.get(by: name) else {
                throw failure("Nhập .bpf hoặc tải config.json trước khi kết nối.")
            }
            await SharedPreferences.selectedProfileID.set(profile.mustID)
            if tunnel == nil {
                try await ExtensionProfile.install()
                try await loadTunnel()
            }
            guard let tunnel else { throw failure("Không tạo được VPN. Kiểm tra chữ ký và quyền Network Extension/App Groups.") }
            try await tunnel.start()
        } catch { errorMessage = error.localizedDescription }
    }
    func importFile(_ url: URL) async {
        guard ready, !busy, !transitioning else { return }
        busy = true
        defer { busy = false }
        do {
            let data = try url.withSecurityScopedAccess { try Data(contentsOf: url) }
            let text = try await validated(data, bpf: url.pathExtension.lowercased() == "bpf")
            try await save(text)
            UserDefaults.standard.set(true, forKey: "localPreviewPending")
            imported = true
        } catch { errorMessage = error.localizedDescription }
    }
    func exportJSON() async -> URL? {
        guard ready, !busy else { return nil }
        do {
            guard let profile = try await ProfileManager.get(by: name) else { throw failure("Chưa có cấu hình để xuất.") }
            let text = try await profile.readAsync()
            let url = FileManager.default.temporaryDirectory.appendingPathComponent("config.json")
            try Data(text.utf8).write(to: url, options: [.atomic])
            return url
        } catch { errorMessage = error.localizedDescription; return nil }
    }
}

struct MainView: View {
    @StateObject private var controller = OnlineController()
    @Environment(\.scenePhase) private var phase
    @State private var picker = false
    @State private var share: ShareFile?
    private let cyan = Color(red: 0.16, green: 0.91, blue: 1)
    private var statusColor: Color { controller.connected ? cyan : Color.white.opacity(0.28) }
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                Color(red: 0.018, green: 0.026, blue: 0.05).ignoresSafeArea()
                RadialGradient(colors: [cyan.opacity(0.14), .clear], center: .center, startRadius: 1, endRadius: 360).ignoresSafeArea()
                Canvas { context, size in
                    var grid = Path()
                    for x in stride(from: CGFloat(0), to: size.width, by: 36) { grid.move(to: CGPoint(x: x, y: 0)); grid.addLine(to: CGPoint(x: x, y: size.height)) }
                    for y in stride(from: CGFloat(0), to: size.height, by: 36) { grid.move(to: CGPoint(x: 0, y: y)); grid.addLine(to: CGPoint(x: size.width, y: y)) }
                    context.stroke(grid, with: .color(cyan.opacity(0.035)), lineWidth: 0.6)
                }.ignoresSafeArea().accessibilityHidden(true)
                VStack(spacing: 0) {
                    HStack { Spacer(); Circle().fill(statusColor).frame(width: 7, height: 7).shadow(color: statusColor, radius: 9) }
                        .padding(32)
                    Spacer()
                    Text("VNBAPEX BYPASS")
                        .font(.system(size: min(28, geometry.size.width / 13), weight: .bold, design: .monospaced))
                        .tracking(2.2).foregroundStyle(.white)
                        .shadow(color: cyan.opacity(0.45), radius: 16)
                        .padding(.bottom, 54)
                    Button { Task { await controller.toggle() } } label: {
                        ZStack {
                            Circle().stroke(cyan.opacity(0.12), lineWidth: 1).frame(width: 180, height: 180)
                            Circle().stroke(statusColor.opacity(0.35), lineWidth: 1).frame(width: 154, height: 154)
                            Circle().fill(.white.opacity(0.035)).overlay(Circle().stroke(cyan.opacity(0.45), lineWidth: 1)).frame(width: 126, height: 126)
                                .shadow(color: cyan.opacity(controller.connected ? 0.35 : 0.08), radius: 32)
                            if controller.busy || controller.transitioning { ProgressView().tint(cyan).scaleEffect(1.4) }
                            else { Image(systemName: "power").font(.system(size: 36, weight: .light)).foregroundStyle(controller.connected ? cyan : .white.opacity(0.65)) }
                        }
                    }.buttonStyle(.plain).disabled(controller.busy || controller.transitioning)
                        .accessibilityLabel(controller.connected ? "Ngắt VPN" : "Kết nối VPN")
                    Spacer()
                    HStack(spacing: 30) {
                        icon("square.and.arrow.down", label: "Nhập BPF hoặc JSON") { picker = true }
                        icon("arrow.triangle.2.circlepath", label: "Cập nhật JSON từ xa") { Task { await controller.refresh() } }
                        icon("square.and.arrow.up", label: "Xuất config.json") { Task { if let url = await controller.exportJSON() { share = ShareFile(url: url) } } }
                    }.padding(20).background(.white.opacity(0.025), in: Capsule()).overlay(Capsule().stroke(.white.opacity(0.07), lineWidth: 1))
                        .padding(.bottom, 40)
                }
            }
        }
        .task {
            await controller.initialize()
            while !Task.isCancelled {
                do { try await Task.sleep(nanoseconds: 900_000_000_000) } catch { break }
                if phase == .active { await controller.refresh(showError: false) }
            }
        }
        .onChange(of: phase) { value in if value == .active { Task { await controller.refresh(showError: false) } } }
        .fileImporter(isPresented: $picker, allowedContentTypes: [.data, .json]) { result in
            switch result {
            case .success(let url): Task { await controller.importFile(url) }
            case .failure(let error): controller.errorMessage = error.localizedDescription
            }
        }
        .onOpenURL { url in
            if ["bpf", "json"].contains(url.pathExtension.lowercased()) { Task { await controller.importFile(url) } }
        }
        .sheet(item: $share) { file in ShareSheet(url: file.url) }
        .alert("VNBAPEX BYPASS", isPresented: Binding(get: { controller.errorMessage != nil }, set: { if !$0 { controller.errorMessage = nil } })) {
            Button("Đóng", role: .cancel) { controller.errorMessage = nil }
        } message: { Text(controller.errorMessage ?? "") }
        .alert("VNBAPEX BYPASS", isPresented: $controller.imported) {
            Button("Đóng", role: .cancel) {}
        } message: { Text("Đã nhập. Dùng biểu tượng xuất để lưu config.json rồi tải lên GitHub. Khi cập nhật từ xa, cấu hình trên GitHub sẽ thay thế cấu hình này.") }
    }
    private func icon(_ symbol: String, label: String, action: @escaping () -> Void) -> some View {
        Button(action: action) { Image(systemName: symbol).font(.system(size: 19, weight: .light)).foregroundStyle(cyan.opacity(0.75)).frame(width: 34, height: 30) }
            .buttonStyle(.plain).disabled(controller.busy || controller.transitioning).accessibilityLabel(label)
    }
}
