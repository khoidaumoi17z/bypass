// SPDX-License-Identifier: GPL-3.0-or-later
import SwiftUI
import Library

@main
struct Application: App {
    var body: some Scene {
        WindowGroup { MainView().preferredColorScheme(.dark) }
    }
}
