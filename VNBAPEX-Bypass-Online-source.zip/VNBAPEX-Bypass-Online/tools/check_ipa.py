from pathlib import Path
import plistlib, sys, zipfile
for arg in sys.argv[1:]:
    with zipfile.ZipFile(arg) as z:
        root='Payload/VNBAPEXBypassOnline.app/'
        info=plistlib.loads(z.read(root+'Info.plist'))
        assert info['CFBundleDisplayName']=='VNBAPEX Bypass Online'
        assert info['RemoteConfigURL'].startswith('https://')
        binary=z.read(root+info['CFBundleExecutable'])
        assert len(binary)>4096 and binary[:4] in [b'\xcf\xfa\xed\xfe',b'\xca\xfe\xba\xbe',b'\xca\xfe\xba\xbf'], 'Missing Mach-O executable'
        extension=root+'PlugIns/Extension.appex/'
        extinfo=plistlib.loads(z.read(extension+'Info.plist'))
        assert extinfo['CFBundleIdentifier']==info['CFBundleIdentifier']+'.extension'
        assert extinfo['NSExtension']['NSExtensionPointIdentifier']=='com.apple.networkextension.packet-tunnel'
        assert len(z.read(extension+extinfo['CFBundleExecutable']))>4096
        assert any(n.startswith(root+'Frameworks/Library.framework/') for n in z.namelist()),'Missing real VPN framework'
        assert not any(n.endswith('.mobileprovision') for n in z.namelist()) or 'unsigned' not in Path(arg).name
        print('PASS: app, Mach-O, real packet tunnel, bundle IDs, remote HTTPS URL:',Path(arg).name)
