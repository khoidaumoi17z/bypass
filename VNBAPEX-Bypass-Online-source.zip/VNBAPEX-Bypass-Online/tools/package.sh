#!/usr/bin/env bash
set -euo pipefail
apple_dir="$1"
output_dir="$2"
mkdir -p "$output_dir"
output_dir="$(cd "$output_dir" && pwd)"
archive_dir="$output_dir/VNBAPEX.xcarchive"
cd "$apple_dir"
args=(-project sing-box.xcodeproj -scheme SFI -configuration Release -destination 'generic/platform=iOS' -archivePath "$archive_dir" -derivedDataPath "$output_dir/DerivedData" -skipPackagePluginValidation DISABLE_SWIFTLINT=1)
if [[ "${SIGNED_BUILD:-false}" == true ]]; then
  xcodebuild archive "${args[@]}" | tee "$output_dir/archive.log"
  xcodebuild -exportArchive -archivePath "$archive_dir" -exportPath "$output_dir/export" -exportOptionsPlist "$RUNNER_TEMP/vnbapex-signing/ExportOptions.plist" | tee "$output_dir/export.log"
  cp "$output_dir/export/VNBAPEXBypassOnline.ipa" "$output_dir/VNBAPEX-Bypass-Online.ipa"
else
  xcodebuild archive "${args[@]}" CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY= | tee "$output_dir/archive.log"
  package_dir="$(mktemp -d)"
  trap 'rm -rf "$package_dir"' EXIT
  mkdir -p "$package_dir/Payload"
  ditto "$archive_dir/Products/Applications/VNBAPEXBypassOnline.app" "$package_dir/Payload/VNBAPEXBypassOnline.app"
  ditto -c -k --keepParent "$package_dir/Payload" "$output_dir/VNBAPEX-Bypass-Online-unsigned.ipa"
fi
python3 "$PACKAGE_ROOT/tools/check_ipa.py" "$output_dir"/VNBAPEX-Bypass-Online*.ipa
cd "$output_dir"
shasum -a 256 VNBAPEX-Bypass-Online*.ipa > SHA256.txt
