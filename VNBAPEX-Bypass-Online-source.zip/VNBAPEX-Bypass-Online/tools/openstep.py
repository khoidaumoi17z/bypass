"""Checks project structure only; this is not a Swift compiler or iOS test."""
from pathlib import Path
import json
import plistlib
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
TOKEN = re.compile(r'\s+|//[^\n]*|/\*.*?\*/|"(?:\\.|[^"\\])*"|[{}()=;,]|[^\s{}()=;,]+', re.S)

def parse_openstep(text):
    tokens = [m.group() for m in TOKEN.finditer(text)
              if not m.group().isspace() and not m.group().startswith(('//', '/*'))]
    index = 0
    def take(expected=None):
        nonlocal index
        value = tokens[index]
        index += 1
        if expected is not None:
            assert value == expected, (value, expected)
        return value
    def value():
        token = take()
        if token == '{':
            result = {}
            while tokens[index] != '}':
                key = take()
                if key.startswith('"'): key = json.loads(key)
                take('=')
                assert key not in result, ('duplicate key', key)
                result[key] = value()
                take(';')
            take('}')
            return result
        if token == '(':
            result = []
            while tokens[index] != ')':
                result.append(value())
                if tokens[index] == ',': take(',')
                else: assert tokens[index] == ')'
            take(')')
            return result
        return json.loads(token) if token.startswith('"') else token
    result = value()
    assert index == len(tokens), 'trailing tokens'
    return result
