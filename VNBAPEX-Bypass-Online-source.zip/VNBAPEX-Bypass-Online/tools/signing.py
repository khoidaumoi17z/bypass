#!/usr/bin/env python3
"""Optional CI signing using user-owned Apple credentials. Never prints secrets."""
import base64, datetime, json, os, plistlib, subprocess, sys
from pathlib import Path
from openstep import parse_openstep
from prepare import emit

apple=Path(sys.argv[1]); signing=Path(os.environ['RUNNER_TEMP'])/'vnbapex-signing'
signing.mkdir(mode=0o700,exist_ok=True)
required=['APPLE_CERTIFICATE_P12','APPLE_CERTIFICATE_PASSWORD','APPLE_APP_PROFILE','APPLE_TUNNEL_PROFILE']
if any(not os.environ.get(k) for k in required):
    raise SystemExit('Signed build requires all four APPLE_* repository secrets; choose unsigned otherwise.')
def run(args):
    subprocess.run(args,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
cert=signing/'cert.p12';cert.write_bytes(base64.b64decode(os.environ[required[0]]))
keychain=signing/'build.keychain-db'
import secrets
password=secrets.token_urlsafe(32)
run(['security','create-keychain','-p',password,str(keychain)])
run(['security','set-keychain-settings','-lut','21600',str(keychain)])
run(['security','unlock-keychain','-p',password,str(keychain)])
run(['security','import',str(cert),'-P',os.environ[required[1]],'-A','-t','cert','-f','pkcs12','-k',str(keychain)])
run(['security','set-key-partition-list','-S','apple-tool:,apple:','-s','-k',password,str(keychain)])
run(['security','list-keychains','-d','user','-s',str(keychain)])
project=apple/'sing-box.xcodeproj/project.pbxproj';p=parse_openstep(project.read_text());o=p['objects'];root=o[p['rootObject']]
base=o[o[root['buildConfigurationList']]['buildConfigurations'][0]]['buildSettings']['BASE_PACKAGE_IDENTIFIER']
profiles={};team=None
for target,secret,bundle in [('SFI','APPLE_APP_PROFILE',base),('Extension','APPLE_TUNNEL_PROFILE',base+'.extension')]:
    blob=base64.b64decode(os.environ[secret]); path=signing/(target+'.mobileprovision');path.write_bytes(blob)
    decoded=subprocess.check_output(['security','cms','-D','-i',str(path)],stderr=subprocess.PIPE)
    profile=plistlib.loads(decoded);ent=profile['Entitlements'];profile_team=profile['TeamIdentifier'][0]
    assert ent['application-identifier']==profile_team+'.'+bundle,'Provisioning profile bundle ID mismatch'
    assert 'packet-tunnel-provider' in ent.get('com.apple.developer.networking.networkextension',[]),'Missing Network Extension entitlement'
    assert 'group.'+base in ent.get('com.apple.security.application-groups',[]),'Missing App Group'
    assert profile['ExpirationDate']>datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None),'Expired profile'
    assert team in (None,profile_team),'Profiles must belong to the same team';team=profile_team
    folder=Path.home()/'Library/MobileDevice/Provisioning Profiles';folder.mkdir(parents=True,exist_ok=True)
    (folder/(profile['UUID']+'.mobileprovision')).write_bytes(blob)
    profiles[bundle]=profile['UUID']
    native=next(v for v in o.values() if v.get('isa')=='PBXNativeTarget' and v.get('name')==target)
    for config in o[native['buildConfigurationList']]['buildConfigurations']:
        settings=o[config]['buildSettings'];settings['DEVELOPMENT_TEAM']=team;settings['CODE_SIGN_STYLE']='Manual'
        settings['PROVISIONING_PROFILE_SPECIFIER']=profile['UUID']
# Match certificate type to the requested export method.
method=os.environ.get('EXPORT_METHOD','development')
assert method in ('development','ad-hoc')
identity='Apple Development' if method=='development' else 'Apple Distribution'
for v in o.values():
    if v.get('isa')=='XCBuildConfiguration':
        v['buildSettings']['CODE_SIGN_IDENTITY']=identity
project.write_text('// !$*UTF8*$!\n'+emit(p)+'\n')
options={'method':method,'signingStyle':'manual','teamID':team,'signingCertificate':identity,'provisioningProfiles':profiles,'stripSwiftSymbols':True}
(signing/'ExportOptions.plist').write_bytes(plistlib.dumps(options))
print('Apple profiles and entitlements validated; CI signing prepared.')
