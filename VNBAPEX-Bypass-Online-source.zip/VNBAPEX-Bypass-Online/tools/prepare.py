#!/usr/bin/env python3
"""Apply the VNBAPEX UI to the exact locked upstream; keep real packet tunnel APIs."""
from pathlib import Path
import argparse, json, plistlib, re, shutil, subprocess
from urllib.parse import urlsplit
from openstep import parse_openstep

ROOT = Path(__file__).resolve().parents[1]

def emit(value, depth=0):
    pad = '\t' * depth
    if isinstance(value, dict):
        return '{\n' + ''.join(pad+'\t'+json.dumps(k)+' = '+emit(v,depth+1)+';\n' for k,v in value.items())+pad+'}'
    if isinstance(value, list):
        return '(\n'+''.join(pad+'\t'+emit(v,depth+1)+',\n' for v in value)+pad+')'
    return json.dumps(str(value))

def prepare(apple, remote_url, bundle):
    assert urlsplit(remote_url).scheme == 'https' and urlsplit(remote_url).netloc
    assert re.fullmatch(r'[A-Za-z][A-Za-z0-9.-]+', bundle)
    lock = json.loads((ROOT/'upstream-lock.json').read_text())
    revision = subprocess.check_output(['git','-C',str(apple),'rev-parse','HEAD'],text=True).strip()
    assert revision == lock['apple_revision'], 'upstream revision changed'
    project_path = apple/'sing-box.xcodeproj/project.pbxproj'
    project = parse_openstep(project_path.read_text())
    objects = project['objects']
    targets = {o['name']: k for k,o in objects.items() if o.get('isa') == 'PBXNativeTarget'}
    kept = {targets[n] for n in ['SFI','Library','Extension']}
    root = objects[project['rootObject']]
    root['targets'] = [targets[n] for n in ['SFI','Library','Extension']]
    products = {objects[t]['productReference'] for t in kept}
    library = objects[targets['Library']]
    package_ids = {objects[d]['package'] for d in library['packageProductDependencies']}
    root['packageReferences'] = [p for p in root['packageReferences'] if p in package_ids]
    for target in kept:
        obj = objects[target]
        obj['dependencies'] = [d for d in obj.get('dependencies',[]) if objects[d]['target'] in kept]
        if obj['name'] == 'SFI': obj['packageProductDependencies'] = []
        for phase in obj['buildPhases']:
            ph = objects[phase]
            if obj['name'] == 'SFI' and ph['isa'] in ['PBXFrameworksBuildPhase','PBXCopyFilesBuildPhase']:
                ph['files'] = [f for f in ph.get('files',[]) if objects[f].get('fileRef') in products]
        for conf in objects[obj['buildConfigurationList']]['buildConfigurations']:
            settings = objects[conf]['buildSettings']
            settings['DEVELOPMENT_TEAM'] = ''
            settings['CODE_SIGN_STYLE'] = 'Manual'
            settings['IPHONEOS_DEPLOYMENT_TARGET'] = '16.0'
            if obj['name']=='SFI':
                settings['INFOPLIST_KEY_CFBundleDisplayName']='VNBAPEX Bypass Online'
                settings['PRODUCT_NAME']='VNBAPEXBypassOnline'
                settings['MARKETING_VERSION']='1.0.0'
                settings.pop('INFOPLIST_KEY_NSCameraUsageDescription',None)
    # Normalize absolute SDK file refs to SDKROOT so Xcode 26.3 can resolve them.
    for obj in objects.values():
        if obj.get('isa')=='PBXFileReference' and '.sdk/' in obj.get('path',''):
            obj['path']=obj['path'].split('.sdk/',1)[1]; obj['sourceTree']='SDKROOT'
    for c in objects[root['buildConfigurationList']]['buildConfigurations']:
        objects[c]['buildSettings']['BASE_PACKAGE_IDENTIFIER']=bundle
        objects[c]['buildSettings']['APP_GROUP_IDENTIFIER']='group.'+bundle
    # Remove unreachable targets and editor packages so CI only resolves VPN dependencies.
    main_group = objects[root['mainGroup']]
    main_group['children'] = [c for c in main_group['children'] if
        objects[c].get('path') in ['SFI','Library','Extension','Libbox.xcframework','Localizable.xcstrings'] or
        objects[c].get('name') in ['Products','Frameworks']]
    objects[root['productRefGroup']]['children'] = list(products)
    attributes = root.get('attributes', {}).get('TargetAttributes', {})
    root.get('attributes', {})['TargetAttributes'] = {k: v for k,v in attributes.items() if k in kept}
    reachable = set()
    def visit(value):
        if isinstance(value, dict):
            for v in value.values(): visit(v)
        elif isinstance(value, list):
            for v in value: visit(v)
        elif isinstance(value, str) and value in objects and value not in reachable:
            reachable.add(value); visit(objects[value])
    visit(project['rootObject'])
    project['objects'] = {k: v for k,v in objects.items() if k in reachable}
    project_path.write_text('// !$*UTF8*$!\n'+emit(project)+'\n')
    # Only the custom main screen is compiled in the app target.
    for path in (apple/'SFI').glob('*.swift'): path.unlink()
    for path in (ROOT/'Overlay').glob('*.swift'): shutil.copy2(path,apple/'SFI'/path.name)
    variant=apple/'Library/Shared/Variant.swift'
    variant.write_text(variant.read_text().replace('applicationName = "SFI"','applicationName = "VNBAPEX Bypass Online"'))
    ext=apple/'Library/Network/ExtensionProfile.swift'
    src=ext.read_text().replace('let managers = try await NETunnelProviderManager.loadAllFromPreferences()',
        'let managers = try await NETunnelProviderManager.loadAllFromPreferences().filter { ($0.protocolConfiguration as? NETunnelProviderProtocol)?.providerBundleIdentifier == AppConfiguration.extensionBundleID }')
    ext.write_text(src)
    info_path=apple/'SFI/Info.plist'
    info=plistlib.loads(info_path.read_bytes())
    for key in ['NSUbiquitousContainers','NSApplicationServices','BGTaskSchedulerPermittedIdentifiers','UIBackgroundModes']:
        info.pop(key,None)
    info['RemoteConfigURL']=remote_url
    info['CFBundleURLTypes']=[{'CFBundleURLSchemes':['vnbapex']}]
    info['CFBundleDisplayName']='VNBAPEX Bypass Online'
    info_path.write_bytes(plistlib.dumps(info))
    minimal={'com.apple.security.application-groups':['$(APP_GROUP_IDENTIFIER)'],
             'com.apple.developer.networking.networkextension':['packet-tunnel-provider']}
    for f in ['SFI/SFI.entitlements','Extension/Extension.entitlements']:
        (apple/f).write_bytes(plistlib.dumps(minimal))
    # Custom icon, original marks are not presented as VNBAPEX branding.
    icons=apple/'SFI/Assets.xcassets'
    for path in icons.glob('*.appiconset'): shutil.rmtree(path)
    shutil.copytree(ROOT/'Assets/AppIcon.appiconset',icons/'AppIcon.appiconset')
    scheme=apple/'sing-box.xcodeproj/xcshareddata/xcschemes/SFI.xcscheme'
    s=scheme.read_text().replace('sing-box.app','VNBAPEXBypassOnline.app')
    s=re.sub(r'<Testables>.*?</Testables>','<Testables/>',s,flags=re.S)
    scheme.write_text(s)
    # Round-trip verification of the generated OpenStep syntax and selected targets.
    parsed=parse_openstep(project_path.read_text())
    assert [parsed['objects'][t]['name'] for t in parsed['objects'][parsed['rootObject']]['targets']]==['SFI','Library','Extension']
    print('Prepared real sing-box VPN app; remote URL:',remote_url)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('apple',type=Path);p.add_argument('--url',required=True);p.add_argument('--bundle',default='com.vnbapex.bypassonline')
    a=p.parse_args();prepare(a.apple,a.url,a.bundle)
