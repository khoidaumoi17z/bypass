# VNBAPEX Bypass Online

Ứng dụng VPN iOS 16+ dùng lõi sing-box thật, phát triển từ mã nguồn GPL-3.0-or-later của SagerNet. Màn hình chính chỉ có dòng chữ **VNBAPEX BYPASS**, nền tối dạng lưới, ánh cyan, đèn trạng thái và bốn nút biểu tượng. Không có chức năng hack game, inject hoặc né anticheat.

## Làm trên iPhone/iPad bằng GitHub

1. Tải `VNBAPEX-Bypass-Online-source.zip`, `vnbapex-online.yml` và `config.json` được gửi kèm.
2. Trong kho GitHub **public**, nhánh `main`, upload ZIP và `config.json` ở trang Code. Không cần giải nén ZIP.
3. Tạo tệp `.github/workflows/vnbapex-online.yml`, dán toàn bộ nội dung tệp workflow và Commit. Giữ workflow Inspector cũ cũng được: đây là workflow khác.
4. Actions → **Build VNBAPEX Bypass Online IPA** → Run workflow. Để `config_url` trống, `config_branch` là `main`. Lần đầu giữ `signed` tắt nếu chưa có chứng chỉ Apple.
5. Đợi trạng thái Success → vào **Summary**, kéo xuống cuối → **Artifacts** → tải **VNBAPEX-IPA**. Giải nén ZIP artifact để lấy `VNBAPEX-Bypass-Online-unsigned.ipa` (hoặc bản đã ký nếu bật signed).

Workflow tự tải hai revision mã nguồn chính thức đã khóa, build Libbox cho iOS arm64, kiểm tra JSON, archive app cùng packet-tunnel extension và kiểm tra IPA. Tệp IPA chỉ được tạo sau khi job archive/package thành công. Tài liệu này không có nghĩa là workflow đã được chạy trong tài khoản của bạn.

## Địa chỉ HTTPS tự động

Nếu kho của bạn là `khoidaumoi17z/ff`, nhánh `main`, endpoint là:

`https://raw.githubusercontent.com/khoidaumoi17z/ff/main/config.json`

Không cần thuê hosting. Repo phải public để app tải trực tiếp. Nếu repo hoặc nhánh khác, workflow tự thay địa chỉ tương ứng khi build. Có thể nhập URL HTTPS khác ở `config_url`. Khi đã build, chỉ cần sửa/commit **tệp config.json ở gốc repo** để cập nhật cấu hình; không cần build lại app. GitHub có thể cache một thời gian.

**Không đặt mật khẩu VPN/token bí mật trong repo public.** Nếu có thông tin đăng nhập riêng, dùng máy chủ HTTPS có cơ chế cấp cấu hình phù hợp; bản này không cung cấp backend xác thực.

## Chuyển BPF của bạn sang JSON

BPF là container cấu hình của sing-box, không phải JSON đổi đuôi.

- Nút nhập bên trái: chọn `.bpf` hoặc `.json`. App dùng bộ giải mã BPF chính thức và `LibboxCheckConfig` để kiểm tra cấu hình.
- Nút xuất bên phải: lưu/chia sẻ **config.json**. Upload tệp đó đè lên `config.json` ở gốc repo GitHub.
- Nút vòng mũi tên ở giữa: tải JSON từ xa ngay. Sau khi nhập BPF, auto-update được tạm dừng để không đè bản vừa nhập; cập nhật thủ công thành công sẽ bật lại.
- Nút nguồn lớn: bật/tắt VPN. iOS sẽ hiện hộp thoại cho phép thêm cấu hình VPN lần đầu.

App chỉ lấy phần JSON trong BPF; không kế thừa địa chỉ cập nhật hoặc metadata từ BPF. BPF không hợp lệ hoặc không tương thích lõi đã khóa sẽ báo lỗi. Chưa có BPF mới của bạn trong gói này: config mẫu chỉ là TUN + DNS + kết nối direct, **không có máy chủ VPN mã hóa** và không tạo tính năng chống ban. Cấu hình proxy/VPN thực tế cần máy chủ do bạn quản lý.

## Update từ xa hoạt động khi nào?

App kiểm tra khi mở/trở lại foreground, khi bấm cập nhật và mỗi 15 phút trong lúc foreground. iOS không cho cam kết app bị đóng vẫn tải cấu hình liên tục. Chỉ tải HTTPS, từ chối redirect HTTP, giới hạn 2 MB, kiểm tra JSON bằng lõi sing-box rồi mới lưu. Tải thất bại giữ cấu hình cũ. Khi VPN đang chạy, app reload cấu hình; nếu reload lỗi, khôi phục bản đã lưu trước đó và thử reload lại. Bản cấu hình cũ vẫn được lưu ngay cả khi VPN không khôi phục được kết nối; app hiển thị lỗi.

## Chữ ký để VPN thật chạy được

IPA unsigned là sản phẩm build, chưa cài/chạy trực tiếp được trên iOS thông thường. **VPN cần chữ ký hợp lệ cho cả app và extension**, quyền Network Extension `packet-tunnel-provider` và App Groups chung. Chỉ ký thông thường mà không có các quyền này sẽ không đủ.

Bundle ID mặc định:

- App: `com.vnbapex.bypassonline`
- Extension: `com.vnbapex.bypassonline.extension`
- App Group: `group.com.vnbapex.bypassonline`

Bạn cần tài khoản Apple Developer có quyền tương ứng và provisioning profiles cho thiết bị của mình. Bật Network Extensions và App Groups cho hai App ID; tạo nhóm chung. Với bản Development/Ad Hoc, thiết bị phải có trong profiles.

Để GitHub ký luôn IPA, thêm Repository Settings → Secrets and variables → Actions:

| Secret | Nội dung |
|---|---|
| `APPLE_CERTIFICATE_P12` | Chứng chỉ Apple Development hoặc Distribution kèm private key, mã hóa Base64 |
| `APPLE_CERTIFICATE_PASSWORD` | Mật khẩu P12 |
| `APPLE_APP_PROFILE` | Provisioning profile cho app, Base64 |
| `APPLE_TUNNEL_PROFILE` | Provisioning profile cho extension, Base64 |

Sau đó Run workflow với `signed` bật. Chọn `development` cho chứng chỉ Apple Development/profiles Development, hoặc `ad-hoc` cho Apple Distribution/profiles Ad Hoc. Không upload chứng chỉ/private key vào Code. Workflow kiểm tra bundle ID, team, hạn sử dụng và entitlements trước khi ký; xóa keychain tạm cuối job. Khi thay bundle ID trong prepare.py phải tạo profiles/group tương ứng.

## Kiểm chứng và mã nguồn

Đã kiểm tra cú pháp Python/Bash/YAML, OpenStep project round-trip, ba target app/Library/Extension, liên kết framework, cấu hình HTTPS và icon RGB 1024. Chưa chạy Swift compiler/Xcode, Simulator, VPN trên thiết bị hay workflow GitHub ở môi trường Linux hiện tại. Workflow có bước Swift parse và xcodebuild archive để kiểm tra thực tế.

`upstream-lock.json` ghi revision chính xác của nguồn Apple và core. Artifact **VNBAPEX-Source** chứa mã nguồn tương ứng sau khi áp dụng giao diện, công cụ và giấy phép. Mã mới trong gói này được phát hành theo GPL-3.0-or-later như dự án nền.

Nguồn: https://github.com/SagerNet/sing-box-for-apple và https://github.com/SagerNet/sing-box
