# Fix 2 — archive exit code 65

Log người dùng cung cấp ghi tại ExtensionProvider.swift:182:
`error: cannot find LibboxPromotePowerReportDraft in scope`.

Revision Apple đã khóa gọi hàm diagnostic chưa có trong revision stable core đã khóa. prepare.py bỏ duy nhất lời gọi promotion bản nháp báo cáo điện năng; giữ LibboxSetup, OOM, command server và VPN tunnel. Không đổi endpoint JSON, chữ ký hay giao diện.

Kiểm chứng: tái áp dụng lên upstream mới, xác minh lời gọi thiếu không còn và phần khởi tạo VPN giữ nguyên, kiểm tra project/OpenStep/Python/Bash và ZIP. Không có Xcode ở môi trường này; cần chạy workflow mới để kiểm tra archive thật và các bước tiếp theo.

Upload đè VNBAPEX-Bypass-Online-source.zip, commit rồi Actions → Run workflow trên main. Re-run jobs của lần cũ vẫn lấy commit cũ. Không cần thay config.json hoặc workflow cho bản sửa này.
